package com.cultivos.gestioncultivos_backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cultivos.gestioncultivos_backend.model.Inventario;
import com.cultivos.gestioncultivos_backend.service.InventarioService;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    private final InventarioService servicio;

    public InventarioController(InventarioService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<Inventario> listar() {
        return servicio.listar();
    }

    @GetMapping("/insumo/{idInsumo}")
    public List<Inventario> listarPorInsumo(@PathVariable("idInsumo") int idInsumo) {
        return servicio.listarPorInsumo(idInsumo);
    }

    @GetMapping("/{id}")
    public Inventario obtener(@PathVariable("id") int id) {
        return servicio.obtener(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Inventario crear(@RequestBody Inventario producto) {
        return servicio.crear(producto);
    }

    @PutMapping("/{id}")
    public Inventario actualizar(
            @PathVariable("id") int id,
            @RequestBody Inventario producto) {
        return servicio.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable("id") int id) {
        servicio.eliminar(id);
    }

    @GetMapping("/categoria/{categoria}")
    public List<Inventario> buscarPorCategoria(
            @PathVariable("categoria") String categoria) {
        return servicio.listarPorCategoria(categoria);
    }
}
